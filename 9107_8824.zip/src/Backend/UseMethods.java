package Backend;
public interface UseMethods {
    String getSearchKey();
    String lineRepresentation();
}
