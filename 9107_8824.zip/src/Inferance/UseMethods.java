package Inferance;

public interface UseMethods {
    String getSearchKey();
    String lineRepresentation();
}
