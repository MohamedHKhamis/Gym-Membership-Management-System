package Inferance;

public interface LoginCredentials {
    String ADMIN_USERNAME = "admin";
    String ADMIN_PASSWORD = "12345";
    String TRAINER_USERNAME = "trainer";
    String TRAINER_PASSWORD = "56789";
}
