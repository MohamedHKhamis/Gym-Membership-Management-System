package Inferance;

public interface FileNames {
    String TRAINER_FILENAME = "src/Data/Trainers.txt";
    String MEMBER_FILENAME = "src/Data/Members.txt";
    String CLASS_FILENAME = "src/Data/Classes.txt";
    String REGISTRATION_FILENAME = "src/Data/Registration.txt";

}